//
//  SceneDelegate.h
//  ExecutorRunner
//
//  Created by Schuck, Jürgen on 20.11.24.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

