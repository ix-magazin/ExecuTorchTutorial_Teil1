//
//  ViewController.h
//  ExecutorRunner
//
//  Created by Schuck, Jürgen on 20.11.24.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

